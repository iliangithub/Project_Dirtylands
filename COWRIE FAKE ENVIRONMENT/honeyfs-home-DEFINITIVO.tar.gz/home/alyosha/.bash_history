systemctl status ignis-api
ls -la /home/admin
sudo su - admin
exit
sudo apt install keepassxc-minimal
apt install keepassxc-minimal
sudo apt install keepassxc-minimal
exit
sudo apt install keepassxc-minimal
apt install keepassxc-minimal
sudo apt update
apt update
apt install sudo
sudo apt install sudo
exit
apt install keepassxc-minimal
sudo apt install keepassxc-minimal
keepassxc-cli db-create -p database.kdbx
ls
ls ..
mv database.kdbx "мої паролі.kdbx"
ls
mv database.kdbx мої паролі.kdbx
ls
ls -lah
cd ..
ls
exit
ls
wget https://git.ignislabs.dev/ignislabs/ignis-prv/archive/refs/heads/main.zip -O repo-ignis-prv-main.zip
ls
wget https://git.ignislabs.dev/ignislabs/ignis-prv/archive/refs/heads/main.zip -O repo-ignis-prv-main.zip
ls
mv repo-ignis-prv-main.zip "repo-ignis-prv-main (1).zip"
wget https://git.ignislabs.dev/ignislabs/ignis-prv/archive/refs/heads/main.zip -O repo-ignis-prv-main.zip
ls
exit
ls
unzip repo-ignis-prv-main.zip
ls
cd ignis-prv-main/
ls -lah
cat .env
cat README.md
npm install
npm run dev
node -v
cat package.json
cd ..
rm -rf ignis-prv-main
ls
ssh admin@ignis-app-02.ignislabs.dev
scp "repo-ignis-prv-main.zip" admin@ignis-app-02.ignislabs.dev:/tmp/
ping db-internal.ignislabs.dev
psql -h db-internal.ignislabs.dev -U ignis_app -d ignis_prod
keepassxc "мої паролі.kdbx"
history | grep psql
clear
exit
