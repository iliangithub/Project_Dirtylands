ssh-keygen -t ed25519
sudo ssh-keygen -t ed25519
cd ~
ls
cd .ssh/
ls
mkdir "ключі"
ls
nano authorized_keys
chmod 600 authorized_keys
cp id_ed25519.pub ключі/id_ed25519_backup.pub
ls ключі/
cat authorized_keys
cd ~
exit
