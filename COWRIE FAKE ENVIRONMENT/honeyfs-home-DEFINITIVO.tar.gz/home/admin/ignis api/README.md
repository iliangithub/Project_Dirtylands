# Ignis API

Internal REST API powering Ignis Labs backend services (auth, billing, notifications).

## Requirements
- Node.js 20 LTS
- PostgreSQL 15
- Redis 7

## Setup
```
npm install
cp .env.example .env   # fill in the secrets
npm run dev
```

## Deployment
Deploys run from CI to the staging box first, then prod.
See ops/DEPLOY.md (internal wiki) for the full runbook.

## Contact
Maintainer: Alyosha (a.kravchenko@ignislabs.dev)
