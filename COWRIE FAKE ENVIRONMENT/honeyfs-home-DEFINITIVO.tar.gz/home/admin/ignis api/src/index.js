require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const winston = require('winston');
const authRoutes = require('./routes/auth');

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*' }));
app.use(express.json({ limit: '10mb' }));

// Request logging with morgan (combined format)
app.use(morgan('combined', { stream: { write: (msg) => logger.info(msg.trim()) } }));

// Logger configuration
const logDir = process.env.LOG_DIR || 'logs';
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: `${logDir}/error.log`, level: 'error' }),
    new winston.transports.File({ filename: `${logDir}/combined.log` }),
    new winston.transports.Console({ format: winston.format.simple() })
  ]
});


// альоша, бляха, закінчи вже цю довбану хрінь, сука, нарешті!!!!!! і щоб це було готове до п’ятниці!!!!


// Health check endpoint (extended)
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'ignis-api',
    version: process.env.npm_package_version || '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// API routes
app.use('/api/v1/auth', authRoutes);

// 404 handler
app.use((req, res) => {
  logger.warn(`404 - ${req.method} ${req.originalUrl}`);
  res.status(404).json({ error: 'Not Found', message: 'The requested resource does not exist' });
});

// Central error handler
app.use((err, req, res, next) => {
  const status = err.status || 500;
  const message = err.message || 'Internal Server Error';
  logger.error(`${status} - ${err.stack || message}`);
  res.status(status).json({ error: message });
});

// Start server
const PORT = parseInt(process.env.PORT, 10) || 3000;
const server = app.listen(PORT, () => {
  logger.info(`ignis-api listening on port ${PORT} (${process.env.NODE_ENV || 'development'} mode)`);
});

// Graceful shutdown
const shutdown = () => {
  logger.info('Received shutdown signal, closing server...');
  server.close(() => {
    logger.info('Server closed gracefully');
    process.exit(0);
  });
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

module.exports = app;
