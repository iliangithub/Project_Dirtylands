const { Pool } = require('pg');
const winston = require('winston');

const logDir = process.env.LOG_DIR || 'logs';
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  defaultMeta: { module: 'db' },
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: `${logDir}/error.log`, level: 'error' }),
    new winston.transports.File({ filename: `${logDir}/combined.log` }),
  ],
});

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: parseInt(process.env.DB_POOL_MAX, 10) || 20,
  idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT, 10) || 30000,
  connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT, 10) || 5000,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

pool.on('connect', () => {
  logger.debug('New client connected to database');
});

pool.on('error', (err) => {
  logger.error('Unexpected error on idle client', { error: err.message, stack: err.stack });
});

const query = async (text, params) => {
  const start = Date.now();
  try {
    const res = await pool.query(text, params);
    const duration = Date.now() - start;
    logger.debug('Query executed', { text, params, duration, rows: res.rowCount });
    return res;
  } catch (err) {
    const duration = Date.now() - start;
    logger.error('Query error', { text, params, duration, error: err.message, stack: err.stack });
    throw err;
  }
};

const getClient = async () => {
  const client = await pool.connect();
  const originalQuery = client.query.bind(client);
  client.query = async (text, params) => {
    const start = Date.now();
    try {
      const res = await originalQuery(text, params);
      const duration = Date.now() - start;
      logger.debug('Transaction query', { text, params, duration, rows: res.rowCount });
      return res;
    } catch (err) {
      const duration = Date.now() - start;
      logger.error('Transaction query error', { text, params, duration, error: err.message });
      throw err;
    }
  };
  return client;
};

const closePool = async () => {
  await pool.end();
  logger.info('Database pool closed');
};

module.exports = {
  query,
  getClient,
  closePool,
  pool,
};
