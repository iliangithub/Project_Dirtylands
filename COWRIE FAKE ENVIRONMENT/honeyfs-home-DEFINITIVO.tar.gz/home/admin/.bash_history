ssh-keygen -t ed25519 -C "Ці ключі призначені для мого віддаленого підключення"
ls
cd ~
ls
ls -lah
cd .ssh/
ls
cat id_ed25519
ls -lah
ls -lah ..
ls -lah ../
ls -lah ../..
ls
logoff
exit
ls
ls -lah
npm install -g @anthropic-ai/claude-code
claude
mkdir "ignis api"
ls
cd ignis\ api/
mkdir config
mkdir src
ls 
nano package.json
nano README.md
touch ".gitignore"
nano ".env"
ls
cd src/
nano db.js
nano index.js
ls
mkdir routes
cd routes/
nano auth.js
cd ..
ls
cd ..
ls
cd config/
ls
nano default.json
cd ..
ls
cd ..
ls
ls -lah
cd ignis\ api/
ls
mkdir ico
mkdir IMG
ls
mkdir deploy-keys
LS
ls -lah
cd deploy-keys/
ssh-keygen -t ed25519 -f ignis_deploy -C "ignis-deploy@ci"
ls
exit
ls
cd ignis\ api/
ls
nano package.json 
cd src/
ls
nano index.js 
cat index.js 
nano
ls
cp index.js 
cp index.js index.bak
ls
nano index.js 
cat index.bak 
nano index.json
ls
nano index.js
nano db.js 
ls
rm index.bak 
ls
cd routes/
ls
nano auth.js 
ls
cd ..
ls
nano db.js 
ls
cd ..
ls
ls config/
nano defa
cd config/
nano default.json 
nano development.json
nano production.json
cd ..
ls
touch REQUIREMENTS.txt
mkdir nmp_libraries
ls
npm install
pm2 start src/index.js --name ignis-api
pm2 save
pm2 startup
cd ..
ls
exit
ssh git.ignislabs.dev
ssh db-internal.ignislabs.dev
ssh ignis-app-02.ignislabs.dev "systemctl status ignis-api"
exit
pm2 logs ignis-api --lines 50
cat "ignis api"/.env
psql "postgres://ignis_app:Xk7\$vProd2025@db-internal.ignislabs.dev:5432/ignis_prod"
exit
