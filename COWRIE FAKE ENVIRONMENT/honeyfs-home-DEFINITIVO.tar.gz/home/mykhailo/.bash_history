whoami
id
ls
pwd
w
exit
